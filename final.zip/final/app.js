const express = require('express');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const app = express();

// 連接 SQLite 資料庫
const dbPath = path.join(__dirname, 'resource', 'sqlite.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('資料庫連線失敗:', err.message);
    } else {
        console.log('成功連接資料庫:', dbPath);
    }
});

// 中介層
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// 查詢 API：只根據日期搜尋
// 查詢 API：只根據日期搜尋
app.get('/api/pigs', (req, res) => {
    const keyword = req.query.q || '';
    const sql = `
        SELECT * FROM livestock_transactions
        WHERE trade_date LIKE ?
        ORDER BY trade_date DESC
    `;
    db.all(sql, ['%' + keyword + '%'], (err, rows) => {
        if (err) return res.status(500).json({ error: '查詢失敗' });
        res.json(rows);
    });
});
// 爬蟲 API：抓取毛豬價格資料
const fetchPigPrices = require('./crawler');
app.get('/api/crawl-pigs', async (req, res) => {
    const data = await fetchPigPrices();
    if (data.length === 0) {
        return res.status(500).json({ error: '爬蟲失敗或無資料' });
    }
    res.json(data);
});

// 新增毛豬資料 API
app.post('/api/pigs', (req, res) => {
    const { trade_date, total_headcount, avg_weight, avg_price } = req.body;

    if (!trade_date || !total_headcount || !avg_weight || !avg_price) {
        return res.status(400).json({ error: '缺少必要欄位' });
    }

    const sql = `
        INSERT INTO livestock_transactions (trade_date, total_headcount, avg_weight, avg_price)
        VALUES (?, ?, ?, ?)
    `;

    db.run(sql, [trade_date, total_headcount, avg_weight, avg_price], function(err) {
        if (err) {
            console.error('資料寫入失敗:', err.message);
            return res.status(500).json({ error: '寫入資料庫失敗' });
        }

        res.json({
            message: '新增成功',
            id: this.lastID,
            data: { trade_date, total_headcount, avg_weight, avg_price }
        });
    });
});


// 首頁載入 HTML
const fs = require('fs');
app.get('/', (req, res) => {
    fs.readFile(path.join(__dirname, 'public', 'index.html'), 'utf8', (err, html) => {
        if (err) {
            res.status(500).send('載入頁面失敗');
        } else {
            res.send(html);
        }
    });
});


module.exports = app;