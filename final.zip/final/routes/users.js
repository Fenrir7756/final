const app = require('./app');  // 如果你的 express app 在 app.js
app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
