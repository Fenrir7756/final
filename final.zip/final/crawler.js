const axios = require('axios');

async function fetchPigPrices(startDate = '2024-06-01', endDate = '2024-06-06') {
  try {
    const url = 'https://m.moa.gov.tw/api/AnimalTrans/GetTransData';
    const payload = {
      MarketNo: '',
      TransDateS: startDate,
      TransDateE: endDate,
    };

    const headers = {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0',
    };

    const { data } = await axios.post(url, payload, { headers });

    // 資料格式化
    const results = data.map(item => ({
      tradeDate: item.transDate,
      totalHeadcount: item.headcnt,
      avgWeight: item.avgWeight,
      avgPrice: item.avgPrice,
    }));

    console.log(results);
    return results;
  } catch (error) {
    console.error('爬蟲失敗:', error.message);
    return [];
  }
}

module.exports = fetchPigPrices;
